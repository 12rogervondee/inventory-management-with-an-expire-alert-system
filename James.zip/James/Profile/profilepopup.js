document.addEventListener("DOMContentLoaded", function() {
  // Profile icon click event
  document.getElementById("profileIcon").addEventListener("click", function() {
    document.getElementById("profilePopup").style.display = "block";
  });

  // Close popup when clicking outside of it
  document.addEventListener("click", function(event) {
    if (!event.target.closest("#profilePopup") && !event.target.closest("#profileIcon")) {
      document.getElementById("profilePopup").style.display = "none";
    }
  });

  // Logout functionality
  document.getElementById("logout").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent default link behavior
    // Perform logout actions here
    window.location.href = "../signin/signin.html"; 
  });
});