// JavaScript logic for login functionality
function login() {
    var userType = document.getElementById("user-type").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    // Dummy authentication for demonstration
    var authenticated = true; // Dummy authentication
    
    if (authenticated) {
      if (userType === "admin") {
        // Redirect to admin page
        window.location.href = "../dashboard/index.html";
      } else if (userType === "student") {
        // Redirect to student page
        window.location.href = "";
      }
    } else {
      alert("Invalid username or password!");
    }
  }
  